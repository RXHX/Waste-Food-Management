# FoodManagement System #


  
## Request : Only to do push command, don't do pull command follow the below commands only ## 
## Steps you can follow if you want to do git task  ##
   <ul>
   <li> Go search bar And type cmd </li>
   <li> Cmd will open , type these command in sequence </li>
   <li> cd Desktop </li>
   <li> git clone https://github.com/RXHX/CSIS-3175-Android.git</li>
   <li> cd CSIS-3175-Android </li>
   <li> git switch dev </li>
   <li> After you have finished the task on Android , type the command in sequence </li>
   <li> git status </li>
   <li>  git add .  </li>
    <li>  git commit -m " type your message" </li>
     <li>  git push </li>   
   </ul>
    
    
   
    
   ### Week 1 ( 06-March-2022 to 12-March-2022)  ###

| Module | Type |Task | Assigned Member | Status | Deadline   
| ---   | --- |---  | --- | --- | ---
| Login | Primary| Designing the Layout | Done | Pending |  12 March 2022
| Registration | Primary| Designing the Layout | Done | Pending |  12 March 2022
| CustomerChat | Primary| Designing the Layout | NA  | Pending |  12 March 2022
| CustomerOrder | Primary| Designing the Layout | NA  | Pending |  12 March 2022
| CustomerProfile | Primary| Designing the Layout | NA | Pending |  12 March 2022
| CustomerDelivery | Primary| Designing the Layout | NA | Pending |  12 March 2022
| ManagerChat | Primary| Designing the Layout | NA   | Pending |  12 March 2022
| ManagerInventory | Primary| Designing the Layout | NA | Pending |  12 March 2022
| ManagerOrder | Primary| Designing the Layout | NA | Pending |  12 March 2022
| ManagerProfile | Primary| Designing the Layout | NA | Pending |  12 March 2022
| Splash Screen | Miscellaneous | Designing the Layout | Done | Pending |  12 March 2022
| Making Logo |  Miscellaneous |Designing the Layout | Done | Pending |  12 March 2022
 



